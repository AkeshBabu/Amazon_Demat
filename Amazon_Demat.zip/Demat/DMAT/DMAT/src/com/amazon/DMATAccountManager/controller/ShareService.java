package com.amazon.DMATAccountManager.controller;

import com.amazon.DMATAccountManager.db.ShareDAO;
import com.amazon.DMATAccountManager.db.UserDAO;
import com.amazon.DMATAccountManager.model.Share;
import com.amazon.DMATAccountManager.model.Users;

import java.util.List;

public class ShareService {

    private static ShareService shareService = new ShareService();

    ShareDAO dao = new ShareDAO();

    public static ShareService getInstance() {
        return shareService;
    }

    private ShareService(){
//
//		Share share1 = new Share();
//        //share1.id = 1;
//        share1.companyName = "AMAZON";
//        share1.price = "120";
//
//        Share share2 = new Share();
//        //share2.id = 2;
//        share2.companyName = "TCS";
//        share2.price = "150";
//
//        Share share3 = new Share();
//        //share3.id = 3;
//        share3.companyName = "Wipro";
//        share3.price = "180";
//
//        Share share4 = new Share();
//        //share4.id = 4;
//        share4.companyName = "Reliance";
//        share4.price = "150";
//
//        Share share5 = new Share();
//        //share5.id = 5;
//        share5.companyName = "Google";
//        share5.price = "190";
//
//        Share share6 = new Share();
//        //share6.id = 6;
//        share6.companyName = "Meta";
//        share6.price = "100";
//
//        Share share7 = new Share();
//        //share7.id = 7;
//        share7.companyName = "Netflix";
//        share7.price = "200";
//
//        Share share8 = new Share();
//        //share8.id = 8;
//        share8.companyName = "P&G";
//        share8.price = "150";
//
//        Share share9 = new Share();
//        //share9.id = 9;
//        share9.companyName = "Infosys";
//        share9.price = "1790";
//
//        Share share10 = new Share();
//        //share10.id = 10;
//        share10.companyName = "Infoedge";
//        share10.price = "150";
//
//		// Add 10 Shares in DataBase
//		ShareDAO dao = new ShareDAO();
//		dao.insert(share1);
//		dao.insert(share2);
//        dao.insert(share3);
//        dao.insert(share4);
//        dao.insert(share5);
//        dao.insert(share6);
//        dao.insert(share7);
//        dao.insert(share8);
//        dao.insert(share9);
//        dao.insert(share10);

    }

    public Share viewShareDetail(String companyName) {

        String sql = "SELECT * from share where companyName = '"+companyName+"'";
        List<Share> objects = dao.retrieve(sql);
        Share obj=new Share();
        int total=0;
        for(Share object : objects) {
            object.prettyPrint();

           //total= Integer.parseInt(object.price)*quantity;
            obj.id=object.id;
            obj.companyName=object.companyName;
            obj.price=object.price;

        }
        return  obj;
    }

    public void viewAllShareDetail() {

        //String sql = "SELECT * from share where companyName = "+companyName;
        List<Share> objects = dao.retrieve();

        for(Share object : objects) {
            object.prettyPrint();
        }
    }


}
