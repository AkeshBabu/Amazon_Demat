package com.amazon.DMATAccountManager.db;


import com.amazon.DMATAccountManager.model.Users;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class UserDAO implements DAO<Users>{

    DB db = DB.getInstance();

    @Override
    public int insert(Users object) {
        String sql = "INSERT INTO Users (UsersName, accountNumber, password, accountBalance) VALUES ('"+object.UsersName+"', '"+object.accountNumber+"', '"+object.password+"', '"+object.accountBalance+"')";
        return db.executeSQL(sql);
    }

    @Override
    public int update(Users object) {
        String sql = "UPDATE Users set UsersName = '"+object.UsersName+"', accountNumber='"+object.accountNumber+"', password='"+object.password+"', accountBalance='"+object.accountBalance+"' WHERE accountNumber = '"+object.accountNumber+"'";
        return db.executeSQL(sql);
    }

    @Override
    public int delete(Users object) {
        String sql = "DELETE FROM Users WHERE accountNumber = '"+object.accountNumber+"'";
        return db.executeSQL(sql);
    }

    @Override
    public List<Users> retrieve() {

        String sql = "SELECT * from Users";

        ResultSet set = db.executeQuery(sql);

        ArrayList<Users> Users = new ArrayList<Users>();

        try {
            while(set.next()) {

                Users Users = new Users();

                // Read the row from ResultSet and put the data into Users Object
                Users.id = set.getInt("id");
                Users.UsersName = set.getString("UsersName");
                Users.accountNumber = set.getString("accountNumber");
                //Users.email = set.getString("email");
                Users.password = set.getString("password");
                Users.accountBalance = set.getInt("accountBalance");
                //Users.department = set.getString("department");
                //Users.type = set.getInt("type");
                Users.lastUpdatedOn = set.getString("lastUpdatedOn");

                Users.add(Users);
            }
        } catch (Exception e) {
            System.err.println("Something Went Wrong: "+e);
        }


        return Users;
    }

    @Override
    public List<Users> retrieve(String sql) {

        ResultSet set = db.executeQuery(sql);

        ArrayList<Users> Users = new ArrayList<Users>();

        try {
            while(set.next()) {

                Users Users = new Users();

                // Read the row from ResultSet and put the data into Users Object
                Users.id = set.getInt("id");
                Users.UsersName = set.getString("UsersName");
                Users.accountNumber = set.getString("accountNumber");
                //Users.email = set.getString("email");
                Users.password = set.getString("password");
                Users.accountBalance = set.getInt("accountBalance");
                //Users.department = set.getString("department");
                //Users.type = set.getInt("type");
                Users.lastUpdatedOn = set.getString("lastUpdatedOn");

                Users.add(Users);
            }
        } catch (Exception e) {
            System.err.println("Something Went Wrong: "+e);
        }


        return Users;
    }

}
