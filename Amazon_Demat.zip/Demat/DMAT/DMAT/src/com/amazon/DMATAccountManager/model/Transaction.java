package com.amazon.DMATAccountManager.model;


/*

MySQL:
create table Transaction(
	id INT PRIMARY KEY AUTO_INCREMENT,
	shareid INT,
	shareCount INT,
	pricePerShare INT,
	transactedOn DATETIME DEFAULT CURRENT_TIMESTAMP,
	transactionCharges INT,
	sttCharges INT,
	type INT,
	UsersId INT,
	FOREIGN KEY (shareid) REFERENCES Share(id),
	FOREIGN KEY (UsersId) REFERENCES Users(id)

);

*/

public class Transaction {

   public int id ;

   public int shareid;

   public int shareCount;

   public int pricePerShare;

   public String transactedOn;

   public int transactionCharges;

   public int sttCharges;

   public int type;

   public int UsersId;

    public Transaction() {
    }

    public Transaction(int id, int shareid, int shareCount, int pricePerShare, String transactedOn, int transactionCharges, int sttCharges, int type,int UsersId) {
        this.id = id;
        this.shareid = shareid;
        this.shareCount = shareCount;
        this.pricePerShare = pricePerShare;
        this.transactedOn = transactedOn;
        this.transactionCharges = transactionCharges;
        this.sttCharges = sttCharges;
        this.type = type;
        this.UsersId=UsersId;
    }

    public void prettyPrint() {
        System.out.println("~~~~~~~~~~~~~~~~~~~~~");
        System.out.println("ID:\t\t"+id);
        System.out.println("Share ID:\t\t"+shareid);
        System.out.println("Share Count:\t\t"+shareCount);
        System.out.println("Price Per Share:\t"+pricePerShare);
        System.out.println("TransactedOn:\t"+transactedOn);
        System.out.println("Transaction Charges:\t"+transactionCharges);
        System.out.println("STT Charges:\t"+sttCharges);
        System.out.println("Type:\t"+type);
        System.out.println("Users ID:\t"+UsersId);
        System.out.println("~~~~~~~~~~~~~~~~~~~~~");
    }

    @Override
    public String toString() {
        return "Transaction{" +
                "id=" + id +
                ", shareid=" + shareid +
                ", shareCount=" + shareCount +
                ", pricePerShare=" + pricePerShare +
                ", transactedOn='" + transactedOn + '\'' +
                ", transactionCharges=" + transactionCharges +
                ", sttCharges=" + sttCharges +
                ", type=" + type +
                ", UsersId=" + UsersId +
                '}';
    }
}
