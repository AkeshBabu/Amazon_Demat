package com.amazon.DMATAccountManager;

import com.amazon.DMATAccountManager.model.Share;
import com.amazon.DMATAccountManager.model.Transaction;
import com.amazon.DMATAccountManager.model.Users;
import com.amazon.DMATAccountManager.model.UserShares;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.List;

public class CreateAccount extends Menu {

    private static CreateAccount menu = new CreateAccount();

    public static CreateAccount getInstance() {
        return menu;
    }

    private CreateAccount() {

    }

    public void showMenu() {
        System.out.println("Navigating to Users Menu...");

        System.out.println("1: Register");
        System.out.println("2: Cancel");

        System.out.println("Enter Your Choice: ");
        int initialChoice = Integer.parseInt(scanner.nextLine());

        boolean result = false;

        Users Users = new Users();
        if(initialChoice == 1) {

            System.out.println("Enter Your Name:");
            Users.UsersName = scanner.nextLine();

            System.out.println("Enter Your Account Number:");
            Users.accountNumber = scanner.nextLine();

           
            System.out.println("Enter Your Password:");
            Users.password = scanner.nextLine();

            try {
                // Hash the Password of Users :)
                MessageDigest digest = MessageDigest.getInstance("SHA-256");
                byte[] hash = digest.digest(Users.password.getBytes(StandardCharsets.UTF_8));
                Users.password = Base64.getEncoder().encodeToString(hash);
            } catch (Exception e) {
                System.err.println("Something Went Wrong: " + e);
            }

            System.out.println("Enter Your Balance:");
            Users.accountBalance = scanner.nextInt();

            result = auth.registerUsers(Users);
        }else {
            System.err.println("Invalid Choice...");
            System.out.println("Thank You for Using DMAT app");
        }

        if (result) {

            // Link the Users to the Session Users :)
            DMATSession.Users = Users;

            System.out.println("^^^^^^^^^^^^^^^^^^^");
            System.out.println("Account Created Successfully");
            System.out.println("Hello, " + Users.UsersName);
            System.out.println("Its: " + new Date());
            System.out.println("Please Login in to access your account");
            System.out.println("^^^^^^^^^^^^^^^^^^^");

            boolean quit = true;


            while (true) {

//                System.out.println("1: Display DMAT Account Details");
//                System.out.println("2: Deposit Money");
//                System.out.println("3: Withdraw Money");
//                System.out.println("4: Buy Transaction");
//                System.out.println("5: Sell Transaction");
//                System.out.println("6: View Transaction Report");
//                System.out.println("7: Quit Users App");
//                System.out.println("Select an Option");
//
//                int ch = Integer.parseInt(scanner.nextLine());
//
//                switch (ch) {
//                    case 1:
//                        auth.viewAccountDetailUsers(DMATSession.Users.id);
//                        break;
//                    case 2:
//                        //auth.viewAccountDetailUsers(DMATSession.Users.id);
//                        int ba=Users.accountBalance;
//                        System.out.println("Enter the amount you want to deposit");
//                        int depositAmt=Integer.parseInt(scanner.nextLine());
//                        Users.accountBalance=ba+depositAmt;
//                        if(auth.updateUsers(Users)) {
//                            System.out.println("Money Deposited Successfully");
//                        }else {
//                            System.err.println("Deposit Failed...");
//                        }
//
//                        break;
//                    case 3:
//                        //int ba= Users.accountBalance;
//                        System.out.println("Enter the amount you want to withdraw");
//                        int withdrawAmt=Integer.parseInt(scanner.nextLine());
//                        if (withdrawAmt> Users.accountBalance){
//                            System.err.println("Insufficient Balance...");
//                        }else{
//                            Users.accountBalance= Users.accountBalance-withdrawAmt;
//                            if (auth.updateUsers(Users)){
//                                System.out.println("Money Withdrawn Successfully");
//                            }
//                        }
//                        break;
//                    case 4:
//                        //auth.viewAccountDetailUsers(DMATSession.Users.id);
//                        System.out.println("Enter which share you want to buy");
//                        String shareName=scanner.nextLine();
//                        Share share=new Share();
//                        //List<Share> share=new ArrayList<>();
//                        System.out.println("Enter the quantity which you want to buy");
//                        int quantity=Integer.parseInt(scanner.nextLine());
//                        share=shareService.viewShareDetail(shareName);
//
//                        double total=Integer.parseInt(share.price)*quantity;
//                        int transactionCharge= (int) ((0.5*total)/100);
//                        if (transactionCharge<100){
//                            transactionCharge=100;
//                        }
//                        int stt= (int) ((0.1*total)/100);
//                        Users.accountBalance= (int) (Users.accountBalance-total-transactionCharge-stt);
//                        auth.updateUsers(Users);
//
//                        //Setting up Transaction Object
//                        Transaction transaction=new Transaction();
//                        transaction.shareid=share.id;
//                        transaction.shareCount=quantity;
//                        transaction.pricePerShare=Integer.parseInt(share.price);
//                        transaction.transactionCharges=transactionCharge;
//                        transaction.sttCharges=stt;
//                        transaction.type=1;
//                        transaction.UsersId= Users.id;
//                        transactionService.buyTransaction(transaction);
//
//                        //Setting Up Usershare Object
//                        UserShares UserShares=new UserShares();
//                        UserShares.UsersId=Users.id;
//                        UserShares.shareId=share.id;
//                        UserShares.companyName=shareName;
//                        UserShares.shareCount=quantity;
//                        UserShareservice.insertShares(UserShares);
//
//
//
//
//
//                        break;
//                    case 5:
//                        //auth.viewAccountDetailUsers(DMATSession.Users.id);
//                        System.out.println("Enter which share you want to sell");
//                        String sellshareName=scanner.nextLine();
//
//                        System.out.println("Enter the quantity which you want to sell");
//                        int sellQuantity=Integer.parseInt(scanner.nextLine());
//                        Share sellObj=new Share();
//                        sellObj=shareService.viewShareDetail(sellshareName);
//                        double sellTotal=Integer.parseInt(sellObj.price)*sellQuantity;
//                        int selltransactionCharge= (int) ((0.5*sellTotal)/100);
//                        if (selltransactionCharge<100){
//                            selltransactionCharge=100;
//                        }
//                        int sellstt= (int) ((0.1*sellTotal)/100);
//                        Users.accountBalance= (int) (Users.accountBalance+sellTotal-selltransactionCharge-sellstt);
//                        auth.updateUsers(Users);
//
//                        //Setting Up Usershare Object
//                        UserShares sellUserShares=new UserShares();
//                        sellUserShares=UserShareservice.viewShareDetail(DMATSession.Users.id);
//                        sellUserShares.UsersId=Users.id;
//                        sellUserShares.shareId=sellObj.id;
//                        sellUserShares.companyName=sellshareName;
//                        sellUserShares.shareCount=sellUserShares.shareCount-sellQuantity;
//                        UserShareservice.updateUserShares(sellUserShares);
//
//                        //Setting up Sell Transaction Object
//                        Transaction selltransaction=new Transaction();
//                        selltransaction.shareid=sellObj.id;
//                        selltransaction.shareCount=sellUserShares.shareCount;
//                        selltransaction.pricePerShare=Integer.parseInt(sellObj.price);
//                        selltransaction.transactionCharges=selltransactionCharge;
//                        selltransaction.sttCharges=sellstt;
//                        selltransaction.type=2;
//                        selltransaction.UsersId= Users.id;
//                        transactionService.sellTransaction(selltransaction);
//
//
//
//
//
//                        break;
//                    case 6:
//                       // auth.viewAccountDetailUsers(DMATSession.Users.id);
//                        transactionService.viewTransactionDetailUsers(Users.id);
//                        break;
//                    case 7:
//                        System.out.println("Thank You for Using Users App !!");
//                        quit = true;
//                        break;
//
//                    default:
//                        System.err.println("Control coming here...");
//                        break;
//                }

                if (quit) {
                    break;
                }


            }

        } else {
            System.err.println("Authentication Failed..");
        }
    }
}
