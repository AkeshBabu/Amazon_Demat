package com.amazon.DMATAccountManager.db;

import com.amazon.DMATAccountManager.model.Users;
import com.amazon.DMATAccountManager.model.UserShares;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class UserSharesDAO implements DAO<UserShares>{
    DB db = DB.getInstance();

    @Override
    public int insert(UserShares object) {
        String sql = "INSERT INTO UserShares (UsersId, shareId, companyName, shareCount) VALUES ('"+object.UsersId+"', '"+object.shareId+"', '"+object.companyName+"', '"+object.shareCount+"')";
        return db.executeSQL(sql);
    }

    @Override
    public int update(UserShares object) {
        String sql = "UPDATE UserShares set UsersId = '"+object.UsersId+"', shareId='"+object.shareId+"', companyName='"+object.companyName+"', shareCount='"+object.shareCount+"' WHERE UsersId = '"+object.UsersId+"' AND shareId = '"+object.shareId+"'";
        return db.executeSQL(sql);
    }

    @Override
    public int delete(UserShares object) {
        String sql = "DELETE FROM UserShares WHERE id = '"+object.id+"'";
        return db.executeSQL(sql);
    }

    @Override
    public List<UserShares> retrieve() {

        String sql = "SELECT * from UserShares";

        ResultSet set = db.executeQuery(sql);

        ArrayList<UserShares> Usershare = new ArrayList<UserShares>();

        try {
            while(set.next()) {

                UserShares UserShares = new UserShares();

                // Read the row from ResultSet and put the data into Users Object
                UserShares.id = set.getInt("id");
                UserShares.UsersId = set.getInt("UsersId");
                UserShares.shareId = set.getInt("shareId");
                //Users.email = set.getString("email");
                UserShares.companyName = set.getString("companyName");
                UserShares.shareCount = set.getInt("accountBalance");
                //Users.department = set.getString("department");
                //Users.type = set.getInt("type");
                //Users.lastUpdatedOn = set.getString("lastUpdatedOn");

                Usershare.add(UserShares);
            }
        } catch (Exception e) {
            System.err.println("Something Went Wrong: "+e);
        }


        return Usershare;
    }

    @Override
    public List<UserShares> retrieve(String sql) {

        ResultSet set = db.executeQuery(sql);

        ArrayList<UserShares> Usershare = new ArrayList<UserShares>();

        try {
            while(set.next()) {

                UserShares UserShares = new UserShares();

                // Read the row from ResultSet and put the data into Users Object
                UserShares.id = set.getInt("id");
                UserShares.UsersId = set.getInt("UsersId");
                UserShares.shareId = set.getInt("shareId");
                //Users.email = set.getString("email");
                UserShares.companyName = set.getString("companyName");
                UserShares.shareCount = set.getInt("shareCount");
                //Users.department = set.getString("department");
                //Users.type = set.getInt("type");
                //Users.lastUpdatedOn = set.getString("lastUpdatedOn");

                Usershare.add(UserShares);
            }
        } catch (Exception e) {
            System.err.println("Something Went Wrong: "+e);
        }


        return Usershare;
    }

}
