package com.amazon.DMATAccountManager.model;


/*

MySQL:
create table Share(
	id INT PRIMARY KEY AUTO_INCREMENT,
	companyName VARCHAR(256),
	price VARCHAR(256),
	lastUpdatedOn DATETIME DEFAULT CURRENT_TIMESTAMP,
	PRIMARY KEY(id);
);

*/

import java.util.Scanner;
public class Share {

    public int id;

    public String companyName;

    public String price;

    public String lastUpdatedOn;

    public Share() {
    }

    public Share(int id, String companyName, String price, String lastUpdatedOn) {
        this.id = id;
        this.companyName = companyName;
        this.price = price;
        this.lastUpdatedOn = lastUpdatedOn;
    }

    public void prettyPrint() {
        System.out.println("~~~~~~~~~~~~~~~~~~~~~");
        System.out.println("ID:\t\t"+id);
        System.out.println("Company Name:\t\t"+companyName);
        System.out.println("Price:\t\t"+price);
        System.out.println("lastUpdatedOn:\t"+lastUpdatedOn);
        System.out.println("~~~~~~~~~~~~~~~~~~~~~");
    }

    @Override
    public String toString() {
        return "Share{" +
                "id=" + id +
                ", companyName='" + companyName + '\'' +
                ", price='" + price + '\'' +
                ", lastUpdatedOn='" + lastUpdatedOn + '\'' +
                '}';
    }
}
