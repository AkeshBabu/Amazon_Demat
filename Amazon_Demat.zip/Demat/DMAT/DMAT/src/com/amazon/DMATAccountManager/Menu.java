package com.amazon.DMATAccountManager;

import com.amazon.DMATAccountManager.controller.AuthenticationService;
import com.amazon.DMATAccountManager.controller.ShareService;
import com.amazon.DMATAccountManager.controller.TransactionService;
import com.amazon.DMATAccountManager.controller.UserShareservice;
import com.amazon.DMATAccountManager.db.DB;

import java.util.Scanner;

public class Menu {

    AuthenticationService auth = AuthenticationService.getInstance();
    ShareService shareService= ShareService.getInstance();

    TransactionService transactionService= TransactionService.getInstance();

    UserShareservice UserShareservice= com.amazon.DMATAccountManager.controller.UserShareservice.getInstance();

    Scanner scanner = new Scanner(System.in);
    public void showMainMenu() {

        // Initial Menu for the Application
        while(true) {
            System.out.println("1: Quit");
            System.out.println("2: Create D-Mat Account");
            System.out.println("3: Login to Account");

            System.out.println("Select an Option");
            int choice = Integer.parseInt(scanner.nextLine());

            if (choice == 1) {
                System.out.println("Thank You For using DMAT Application");

                // Close the DataBase Connection, when Users has exited the application :)
                DB db = DB.getInstance();
                db.closeConnection();
                scanner.close();
                break;
            }

            try {
                MenuFactory.getMenu(choice).showMenu();
            } catch (Exception e) {
                System.err.println("[Menu] [Exception] Invalid Choice..."+e);
            }



        }


    }

    public void showMenu() {
        System.out.println("Showing the Menu...");
    }

}
