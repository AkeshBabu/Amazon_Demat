package com.amazon.DMATAccountManager;

import com.amazon.DMATAccountManager.model.Users;

public class DMATSession {

    // Can hold the reference of a Users Object :)
    public static Users Users = null;
}
