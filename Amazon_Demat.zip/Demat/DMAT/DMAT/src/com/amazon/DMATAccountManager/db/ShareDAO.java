package com.amazon.DMATAccountManager.db;

import com.amazon.DMATAccountManager.model.Share;
import com.amazon.DMATAccountManager.model.Users;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ShareDAO implements DAO<Share>{


    DB db = DB.getInstance();

    @Override
    public int insert(Share object) {
        String sql = "INSERT INTO Share (companyName, price) VALUES ('"+object.companyName+"', '"+object.price+"')";
        return db.executeSQL(sql);
    }

    @Override
    public int update(Share object) {
        String sql = "UPDATE Share set companyName = '"+object.companyName+"', price='"+object.price+"' WHERE companyName = '"+object.companyName+"'";
        return db.executeSQL(sql);
    }

    @Override
    public int delete(Share object) {
        String sql = "DELETE FROM Share WHERE companyName = '"+object.companyName+"'";
        return db.executeSQL(sql);
    }

    @Override
    public List<Share> retrieve() {

        String sql = "SELECT * from Share";

        ResultSet set = db.executeQuery(sql);

        ArrayList<Share> shares = new ArrayList<Share>();

        try {
            while(set.next()) {

                Share share = new Share();

                // Read the row from ResultSet and put the data into Users Object
                share.id = set.getInt("id");
                share.companyName = set.getString("companyName");
                share.price = set.getString("price");
//                //Users.email = set.getString("email");
//                Users.password = set.getString("password");
//                Users.accountBalance = set.getInt("accountBalance");
//                //Users.department = set.getString("department");
//                //Users.type = set.getInt("type");
                share.lastUpdatedOn = set.getString("lastUpdatedOn");

                shares.add(share);
            }
        } catch (Exception e) {
            System.err.println("Something Went Wrong: "+e);
        }


        return shares;
    }

    @Override
    public List<Share> retrieve(String sql) {

        ResultSet set = db.executeQuery(sql);

        ArrayList<Share> shares = new ArrayList<Share>();

        try {
            while(set.next()) {

                Share share = new Share();

                // Read the row from ResultSet and put the data into Users Object
                share.id = set.getInt("id");
                share.companyName = set.getString("companyName");
                share.price = set.getString("price");
//
                share.lastUpdatedOn = set.getString("lastUpdatedOn");
                //share.lastUpdatedOn = set.getString("lastUpdatedOn");

                shares.add(share);
            }
        } catch (Exception e) {
            System.err.println("Something Went Wrong: "+e);
        }


        return shares;
    }

}
