package com.amazon.DMATAccountManager.controller;


import com.amazon.DMATAccountManager.db.UserDAO;
import com.amazon.DMATAccountManager.model.Users;

import java.util.List;

public class AuthenticationService {
    private static AuthenticationService service = new AuthenticationService();
    UserDAO dao = new UserDAO();

    public static AuthenticationService getInstance() {
        return service;
    }

    private AuthenticationService(){
        /*
		Users Users1 = new Users();
		Users1.id = 3;
		Users1.name = "John Watson";
		Users1.phone = "+91 99999 11111";
		Users1.email = "jon@example.com";
		Users1.password = "admin123";
		Users1.address = "Redwood Shores";
		Users1.department = "admin";
		Users1.type = 1;		// admin

		Users Users2 = new Users();
		Users2.id = 4;
		Users2.name = "Fionna Flynn";
		Users2.phone = "+91 99999 22222";
		Users2.email = "fionna@example.com";
		Users2.password = "fionna123";
		Users2.address = "Country Homes";
		Users2.department = "hr";
		Users2.type = 2;		// Users or visitor

		// Add 2 Users in DataBase
		UserDAO dao = new UserDAO();
		dao.insert(Users1);
		dao.insert(Users2);
        */
    }


    public boolean loginUsers(Users Users) {

        String sql = "SELECT * FROM Users WHERE accountNumber = '"+Users.accountNumber+"' AND password = '"+Users.password+"'";
        List<Users> Users = dao.retrieve(sql);

        if(Users.size() > 0) {
            Users u = Users.get(0);
            Users.id = u.id;
            Users.UsersName = u.UsersName;
            Users.accountNumber = u.accountNumber;
            Users.password = u.password;
            Users.accountBalance = u.accountBalance;
            //Users.department = u.department;
            //Users.type = u.type;
            Users.lastUpdatedOn = u.lastUpdatedOn;
            return true;
        }

        return false;
    }
    public boolean registerUsers(Users Users) {
        //int result = dao.insert(Users);
        //return result > 0;
        return dao.insert(Users) > 0;
    }

    public boolean updateUsers(Users Users) {
        return dao.update(Users) > 0;
    }

    public void viewAccountDetailUsers(int uid) {

        String sql = "SELECT * from Users where id = "+uid;
        List<Users> objects = dao.retrieve(sql);

        for(Users object : objects) {
            object.prettyPrint();
        }
    }

}