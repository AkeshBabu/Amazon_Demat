package com.amazon.DMATAccountManager.db;

import com.amazon.DMATAccountManager.model.Share;
import com.amazon.DMATAccountManager.model.Transaction;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class TransactionDAO implements DAO<Transaction>{

    DB db = DB.getInstance();

    @Override
    public int insert(Transaction object) {
        String sql = "INSERT INTO Transaction (shareid,shareCount,pricePerShare,transactionCharges, sttCharges, type, UsersId) VALUES ('"+object.shareid+"', '"+object.shareCount+"', '"+object.pricePerShare+"', '"+object.transactionCharges+"', '"+object.sttCharges+"', '"+object.type+"', '"+object.UsersId+"')";
        return db.executeSQL(sql);
    }

    @Override
    public int update(Transaction object) {
        String sql = "UPDATE Transaction set shareCount = '"+object.shareCount+"', pricePerShare='"+object.pricePerShare+"' WHERE shareid = '"+object.shareid+"'";
        return db.executeSQL(sql);
    }

    @Override
    public int delete(Transaction object) {
        String sql = "DELETE FROM Transaction WHERE id = '"+object.id+"'";
        return db.executeSQL(sql);
    }

    @Override
    public List<Transaction> retrieve() {

        String sql = "SELECT * from Transaction";

        ResultSet set = db.executeQuery(sql);

        ArrayList<Transaction> transactions = new ArrayList<Transaction>();

        try {
            while(set.next()) {

                Transaction transaction = new Transaction();

                // Read the row from ResultSet and put the data into Users Object
                transaction.id = set.getInt("id");
                transaction.shareid = set.getInt("shareId");
                transaction.shareCount = set.getInt("shareCount");
                transaction.pricePerShare = set.getInt("pricePerShare");
                transaction.transactedOn = set.getString("transactedOn");
                transaction.transactionCharges = set.getInt("transactionCharges");
                transaction.sttCharges = set.getInt("sttCharges");
                transaction.type = set.getInt("type");
                transaction.UsersId = set.getInt("UsersId");

                transactions.add(transaction);
            }
        } catch (Exception e) {
            System.err.println("Something Went Wrong: "+e);
        }


        return transactions;
    }

    @Override
    public List<Transaction> retrieve(String sql) {

        ResultSet set = db.executeQuery(sql);

        ArrayList<Transaction> transactions = new ArrayList<Transaction>();

        try {
            while(set.next()) {

                Transaction transaction = new Transaction();

                // Read the row from ResultSet and put the data into Users Object
                transaction.id = set.getInt("id");
                transaction.shareid = set.getInt("shareId");
                transaction.shareCount = set.getInt("shareCount");
                transaction.pricePerShare = set.getInt("pricePerShare");
                transaction.transactedOn = set.getString("transactedOn");
                transaction.transactionCharges = set.getInt("transactionCharges");
                transaction.sttCharges = set.getInt("sttCharges");
                transaction.type = set.getInt("type");
                transaction.UsersId = set.getInt("UsersId");

                transactions.add(transaction);
            }
        } catch (Exception e) {
            System.err.println("Something Went Wrong: "+e);
        }


        return transactions;
    }

}
