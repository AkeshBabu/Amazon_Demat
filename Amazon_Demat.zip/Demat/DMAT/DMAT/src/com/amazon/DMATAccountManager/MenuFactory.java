package com.amazon.DMATAccountManager;

public class MenuFactory {
    public static Menu getMenu(int type) {

        if(type == 2) {
            return CreateAccount.getInstance();
        }else if (type == 3) {
            return LoginAccount.getInstance();
        }

        return null;
    }
}
