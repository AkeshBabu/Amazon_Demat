package com.amazon.DMATAccountManager.model;
/*
MySQL:
        create table Users(
        id INT PRIMARY KEY AUTO_INCREMENT,
        UsersName VARCHAR(256),
        accountNumber VARCHAR(256),
        password VARCHAR(256),
        accountBalance INT,
        lastUpdatedOn DATETIME DEFAULT CURRENT_TIMESTAMP
        );

 */
public class Users {

    public int id;

    public String UsersName;

    public String accountNumber;

    public String password;

    public int accountBalance;

    public String lastUpdatedOn;

    public Users() {
    }

    public Users(int id, String UsersName, String accountNumber, String password, int accountBalance, String lastUpdatedOn) {
        this.id = id;
        this.UsersName = UsersName;
        this.accountNumber = accountNumber;
        this.password = password;
        this.accountBalance = accountBalance;
        this.lastUpdatedOn = lastUpdatedOn;
    }

    public void prettyPrint() {
        System.out.println("~~~~~~~~~~~~~~~~~~~~~");
        System.out.println("ID:\t\t"+id);
        System.out.println("Users Name:\t\t"+UsersName);
        System.out.println("Account Number:\t\t"+accountNumber);
        System.out.println("Account Balance:\t"+accountBalance);
        System.out.println("Last UpdatedOn:\t"+lastUpdatedOn);
        System.out.println("~~~~~~~~~~~~~~~~~~~~~");
    }

    @Override
    public String toString() {
        return "Users{" +
                "id=" + id +
                ", UsersName='" + UsersName + '\'' +
                ", accountNumber='" + accountNumber + '\'' +
                ", password='" + password + '\'' +
                ", accountBalance=" + accountBalance +
                ", lastUpdatedOn='" + lastUpdatedOn + '\'' +
                '}';
    }
}
