package com.amazon.DMATAccountManager.controller;

import com.amazon.DMATAccountManager.db.ShareDAO;
import com.amazon.DMATAccountManager.db.UserSharesDAO;
import com.amazon.DMATAccountManager.model.Share;
import com.amazon.DMATAccountManager.model.Users;
import com.amazon.DMATAccountManager.model.UserShares;

import java.util.List;

public class UserShareservice {

    private static UserShareservice UserShareservice = new UserShareservice();

    UserSharesDAO dao = new UserSharesDAO();

    public static UserShareservice getInstance() {
        return UserShareservice;
    }

    private UserShareservice(){

    }

    public boolean insertShares(UserShares UserShares) {
        //int result = dao.insert(Users);
        //return result > 0;
        return dao.insert(UserShares) > 0;
    }

    public boolean updateUserShares(UserShares UserShares) {
        return dao.update(UserShares) > 0;
    }

    public UserShares viewShareDetail(int UsersId) {

        String sql = "SELECT * from UserShares where UsersId = '"+UsersId+"'";
        List<UserShares> objects = dao.retrieve(sql);
        int total=0;
        UserShares UserShares=new UserShares();
        for(UserShares object : objects) {
            object.prettyPrint();
            UserShares.UsersId=object.UsersId;
            UserShares.shareId=object.shareId;
            UserShares.companyName=object.companyName;
            UserShares.shareCount=object.shareCount;
            //total= Integer.parseInt(object.price)*quantity;
        }
        return UserShares;
    }

    public void viewAllShareDetail() {

        //String sql = "SELECT * from share where companyName = "+companyName;
        List<UserShares> objects = dao.retrieve();

        for(UserShares object : objects) {
            object.prettyPrint();
        }
    }


}
