package com.amazon.DMATAccountManager;

public class Config {
    // Symbolic Constants :)
    public static double TransactionCharge = 0.5;
    public static double SecuritiesTransferTax = 0.1;
    public static double MinimumTransactionCharge = 100;
}
