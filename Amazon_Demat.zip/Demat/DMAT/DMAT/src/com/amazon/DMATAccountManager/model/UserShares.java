package com.amazon.DMATAccountManager.model;


/*
MySQL:
        create table UserShares(
        id INT PRIMARY KEY AUTO_INCREMENT,
        UsersId INT,
        shareID INT,
        companyName varchar(256),
        shareCount INT
        );

 */
public class UserShares {

    public int id;
    public int UsersId;

    public int shareId;
    public String companyName;

    public int shareCount;

    public UserShares() {
    }



    public UserShares(int id, int UsersId, int shareId, String companyName, int shareCount) {
        this.id = id;
        this.UsersId = UsersId;
        this.shareId = shareId;
        this.companyName = companyName;
        this.shareCount = shareCount;
    }

    public void prettyPrint() {
        System.out.println("~~~~~~~~~~~~~~~~~~~~~");
        System.out.println("ID:\t\t"+id);
        System.out.println("Users ID:\t\t"+UsersId);
        System.out.println("Share ID:\t\t"+shareId);
        System.out.println("Company Name:\t"+companyName);
        System.out.println("Share Count:\t"+shareCount);
        System.out.println("~~~~~~~~~~~~~~~~~~~~~");
    }

    @Override
    public String toString() {
        return "UserShares{" +
                "id=" + id +
                ", UsersId=" + UsersId +
                ", shareId=" + shareId +
                ", companyName='" + companyName + '\'' +
                ", shareCount=" + shareCount +
                '}';
    }
}
